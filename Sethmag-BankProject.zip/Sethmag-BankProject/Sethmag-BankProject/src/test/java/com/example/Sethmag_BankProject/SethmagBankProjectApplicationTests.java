package com.example.Sethmag_BankProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SethmagBankProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
